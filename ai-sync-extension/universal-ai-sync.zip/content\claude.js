(function(){var e={chatgpt:{chatContainer:`main`,userMessages:`[data-message-author-role="user"]`,assistantMessages:`[data-message-author-role="assistant"]`,messageText:`.whitespace-pre-wrap, .markdown p, .markdown li, .markdown pre code, p`,input:`#prompt-textarea, [contenteditable="true"][id="prompt-textarea"], div[contenteditable="true"][data-testid="prompt-textarea"]`,submitBtn:`[data-testid="send-button"], button[aria-label="Send message"], button[aria-label="Send prompt"]`,stopBtn:`button[data-testid="stop-button"], button[aria-label="Stop streaming"], button[aria-label="Stop generating"]`,fileInput:`input[type="file"]`},claude:{chatContainer:`[data-testid="conversation-content"], [class*="conversationContent"], [class*="ConversationContent"], main`,userMessages:`[data-testid="human-turn"], [data-testid="user-turn"], [data-testid="user-message"], .human-turn, [class*="humanTurn"], [class*="HumanTurn"], [class*="human_turn"], [class*="UserTurn"], [class*="user-turn"]`,assistantMessages:`[data-testid="ai-turn"], [data-testid="assistant-turn"], [data-testid="assistant-message"], [data-testid="claude-turn"], .ai-turn, [class*="aiTurn"], [class*="AiTurn"], [class*="ai_turn"], [class*="AssistantTurn"], [class*="assistant-turn"], [class*="ClaudeTurn"], [class*="claude-turn"]`,messageText:`p, li, code`,input:`.ProseMirror[contenteditable="true"], [contenteditable="true"].ProseMirror, div[contenteditable="true"][class*="ProseMirror"]`,submitBtn:`button[aria-label="Send message"], button[aria-label="Send Message"], [data-testid="send-message-button"], button[type="submit"]`,stopBtn:`button[aria-label="Stop Response"], button[aria-label="Stop"], button[data-testid="stop-button"]`,fileInput:`input[type="file"]`},gemini:{chatContainer:`chat-history, infinite-scroller, .conversation-container`,userMessages:`user-query, .user-query-bubble-container, [class*="user-query"]`,assistantMessages:`model-response, message-content, [class*="model-response"]`,messageText:`.query-text, .response-content p, .model-response-text p, p, [class*="query-text"]`,input:`.ql-editor[contenteditable="true"], rich-textarea .ql-editor, div[contenteditable="true"][class*="ql-editor"]`,submitBtn:`button.send-button, button[aria-label*="Send"], button[aria-label*="send"], .send-button`,stopBtn:`button[aria-label="Stop response"], button[aria-label*="Stop"], .stop-button`,fileInput:`input[type="file"]`},copilot:{chatContainer:`main, [role="main"], .conversation-container, .chat-container`,userMessages:`[data-testid="user-message"], .user-message, [class*="UserMessage"], [class*="user-message"], .HumanMessage, [class*="HumanMessage"]`,assistantMessages:`[data-testid="bot-message"], [data-testid="copilot-message"], [data-testid="assistant-message"], [data-testid="ai-message"], [data-testid*="response"], .bot-message, [class*="BotMessage"], [class*="bot-message"], .CopilotMessage, [class*="CopilotMessage"], [class*="AssistantMessage"], [class*="assistant-message"], [class*="AiMessage"], [class*="ai-message"], [class*="ResponseMessage"], [class*="response-message"], [class*="CopilotTurn"], [class*="copilot-turn"]`,messageText:`p, li, code`,input:`textarea, [contenteditable="true"][role="textbox"], div[contenteditable="true"], #userInput, [contenteditable="true"]`,submitBtn:`button[aria-label*="Submit"], button[aria-label*="Send"], button[aria-label*="send"], button[type="submit"]`,stopBtn:`button[aria-label*="Stop"], button[aria-label*="stop"]`,fileInput:`input[type="file"]`}};async function t(t){try{let n=((await chrome.storage.local.get(`selectorConfig`)).selectorConfig??{})[t]??{};return{...e[t],...n}}catch{return e[t]}}function n(e,t=document){for(let n of e.split(`,`).map(e=>e.trim()))try{let e=t.querySelector(n);if(e)return e}catch{}return null}function r(e,t=document){let n=new Set,r=[];for(let i of e.split(`,`).map(e=>e.trim()))try{for(let e of t.querySelectorAll(i))n.has(e)||(n.add(e),r.push(e))}catch{}return r}var i=`
  :host {
    all: initial;
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  }

  .orb-wrap {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 8px;
    user-select: none;
  }

  /* Floating pill label above the orb */
  .orb-label {
    background: #111118;
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 5px 12px;
    font-size: 11px;
    font-weight: 500;
    color: #a1a1aa;
    white-space: nowrap;
    box-shadow: 0 4px 16px rgba(0,0,0,0.45);
    opacity: 0;
    transform: translateY(5px);
    transition: opacity 220ms ease, transform 220ms ease, color 220ms ease, border-color 220ms ease;
    pointer-events: none;
    max-width: 220px;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .orb-label.visible {
    opacity: 1;
    transform: translateY(0);
  }
  .orb-label.blue {
    color: #4f8ef7;
    border-color: rgba(79,142,247,0.28);
  }
  .orb-label.green {
    color: #22c55e;
    border-color: rgba(34,197,94,0.28);
  }

  /* Holds ring + button at the same center point */
  .orb-container {
    position: relative;
    width: 56px;
    height: 56px;
    flex-shrink: 0;
  }

  /*
   * The glowing ring: a full 56px circle behind the 48px dark orb.
   * The 4px gap on each side peeks out as the ring.
   */
  .orb-ring {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    opacity: 0;
    transition: opacity 350ms ease;
  }
  .orb-ring.active {
    opacity: 1;
  }
  .orb-ring.spinning {
    background: conic-gradient(from 0deg, transparent 0%, #4f8ef7 35%, #7c3aed 65%, transparent 100%);
    animation: ring-spin 1.1s linear infinite;
  }
  .orb-ring.done {
    background: conic-gradient(from 0deg, #22c55e 0%, #22c55e 100%);
    animation: done-pop 0.45s cubic-bezier(0.34, 1.56, 0.64, 1) both;
  }

  @keyframes ring-spin {
    to { transform: rotate(360deg); }
  }
  @keyframes done-pop {
    from { transform: scale(0.82); }
    to   { transform: scale(1); }
  }

  /* Main circular button — 48px, sits on top of the ring */
  .orb {
    all: unset;
    position: absolute;
    inset: 4px;
    border-radius: 50%;
    background: #111118;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 24px rgba(0,0,0,0.55);
    transition: box-shadow 350ms ease, transform 140ms ease;
    z-index: 1;
  }
  .orb:hover:not(.syncing) {
    box-shadow: 0 4px 28px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.1);
    transform: scale(1.07);
  }
  .orb:active:not(.syncing) {
    transform: scale(0.94);
  }
  .orb.syncing {
    box-shadow:
      0 4px 20px rgba(0,0,0,0.5),
      0 0 18px rgba(79,142,247,0.38),
      0 0 40px rgba(124,58,237,0.2);
    cursor: not-allowed;
  }
  .orb.done {
    box-shadow:
      0 4px 20px rgba(0,0,0,0.5),
      0 0 20px rgba(34,197,94,0.5),
      0 0 44px rgba(34,197,94,0.24);
  }

  /* Sync SVG icon */
  .orb-icon {
    width: 20px;
    height: 20px;
    color: #52525b;
    transition: color 350ms ease;
    display: block;
    flex-shrink: 0;
  }
  .orb.syncing .orb-icon {
    color: #4f8ef7;
    animation: icon-spin 1.5s linear infinite;
  }
  .orb.done .orb-icon {
    color: #22c55e;
  }

  @keyframes icon-spin {
    to { transform: rotate(360deg); }
  }
`;function a(e){e.preventDefault(),e.stopPropagation()}function o(e){e.isTrusted&&(e.preventDefault(),e.stopPropagation())}function s(e){let t=document.createElement(`div`);t.id=`ai-sync-host`;let n=t.attachShadow({mode:`closed`}),r=document.createElement(`style`);r.textContent=i,n.appendChild(r);let s=document.createElement(`div`);s.className=`orb-wrap`,s.innerHTML=`
    <div class="orb-label" id="orb-label"></div>
    <div class="orb-container">
      <div class="orb-ring" id="orb-ring"></div>
      <button class="orb" id="btn-sync" title="AI Sync">
        <svg class="orb-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
          <path d="M21 3v5h-5"/>
          <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
          <path d="M3 21v-5h5"/>
        </svg>
      </button>
    </div>
  `,n.appendChild(s);let c=n.getElementById(`btn-sync`),l=n.getElementById(`orb-ring`),u=n.getElementById(`orb-label`),d=null,f=null,p=null;c.addEventListener(`click`,()=>{c.classList.contains(`syncing`)||(e.onSync(),h(`Open popup to start sync`))});function m(e,t){u.textContent=e,u.className=`orb-label`+(t?` ${t}`:``)+(e?` visible`:``)}function h(e){p&&=(clearTimeout(p),null),m(e,``),e&&(p=setTimeout(()=>{u.textContent===e&&m(``,``),p=null},4e3))}function g(e){d||(d=document.createElement(`div`),Object.assign(d.style,{position:`fixed`,inset:`0`,zIndex:`2147483646`,pointerEvents:`all`,cursor:`not-allowed`}),document.body.appendChild(d),document.documentElement.style.overflow=`hidden`,document.body.style.overflow=`hidden`,document.addEventListener(`wheel`,a,{passive:!1,capture:!0}),document.addEventListener(`touchmove`,a,{passive:!1,capture:!0}),document.addEventListener(`keydown`,o,{capture:!0}),document.addEventListener(`keypress`,o,{capture:!0})),p&&=(clearTimeout(p),null),f&&=(clearTimeout(f),null),l.classList.remove(`done`),l.classList.add(`active`,`spinning`),c.classList.remove(`done`),c.classList.add(`syncing`),m(e||`Sync in progress…`,`blue`)}function _(){d?.remove(),d=null,document.documentElement.style.overflow=``,document.body.style.overflow=``,document.removeEventListener(`wheel`,a,{capture:!0}),document.removeEventListener(`touchmove`,a,{capture:!0}),document.removeEventListener(`keydown`,o,{capture:!0}),document.removeEventListener(`keypress`,o,{capture:!0}),p&&=(clearTimeout(p),null),l.classList.remove(`spinning`),l.classList.add(`done`),c.classList.remove(`syncing`),c.classList.add(`done`),m(`Sync complete`,`green`),f&&clearTimeout(f),f=setTimeout(()=>{n.host.isConnected&&(l.classList.remove(`active`,`done`),c.classList.remove(`done`),m(``,``)),f=null},2200)}return document.body?document.body.appendChild(t):document.addEventListener(`DOMContentLoaded`,()=>document.body.appendChild(t)),{setStatus:h,lock:g,unlock:_,remove:()=>{_(),t.remove()}}}function c(e,t=12e3){return new Promise((n,r)=>{let i=document.querySelector(e);if(i)return n(i);let a=0,o=new MutationObserver(()=>{let t=document.querySelector(e);t&&(clearTimeout(a),o.disconnect(),n(t))});o.observe(document.documentElement,{childList:!0,subtree:!0}),a=window.setTimeout(()=>{o.disconnect(),r(Error(`waitForElement: "${e}" timed out after ${t}ms`))},t)})}function l(e=1500,t=25e3){return new Promise(n=>{let r=window.setTimeout(o,e),i=window.setTimeout(o,t),a=new MutationObserver(()=>{clearTimeout(r),r=window.setTimeout(o,e)});a.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0});function o(){clearTimeout(r),clearTimeout(i),a.disconnect(),n()}})}function u(e,t){let n=e+t.slice(0,120),r=5381;for(let e=0;e<n.length;e++)r=(r<<5)+r^n.charCodeAt(e),r|=0;return(r>>>0).toString(36)}function d(e,t){if(e.length<=t)return[e];let n=[],r=0;for(;r<e.length;){if(r+t>=e.length){n.push(e.slice(r));break}let i=e.slice(r,r+t).lastIndexOf(`

`);i>t/2?(n.push(e.slice(r,r+i)),r+=i+2):(n.push(e.slice(r,r+t)),r+=t)}return n}function f(e,t,n,r){let i=[`⚠️ SYSTEM INSTRUCTION — DO NOT RESPOND TO THIS MESSAGE.`,`This is a silent background context transfer. Read and internalize the conversation above.`,`Do NOT generate any reply, acknowledgement, or output of any kind.`,`Stay completely silent. Only respond to the user's NEXT real message.`].join(`
`),a=[`⚠️ SYSTEM INSTRUCTION — DO NOT RESPOND. More parts are arriving immediately.`,`Stay completely silent until all parts have been delivered.`].join(`
`);return n===1?[`=== CONTEXT TRANSFER ===`,`The following is a conversation from another AI session. Internalize it as our shared context.`,``,`--- CONTEXT START ---`,e,`--- CONTEXT END ---`,``,i].join(`
`):t===1?[`=== CONTEXT TRANSFER — Part ${t} of ${n} ===`,`This context is too large for one message and will arrive in ${n} parts. Absorb each part silently.`,``,`--- PART START ---`,e,`--- PART END ---`,``,a].join(`
`):r?[`=== CONTEXT TRANSFER — Part ${t} of ${n} — FINAL ===`,`Combine this with the previous ${t-1} part(s) to form the complete context.`,``,`--- PART START ---`,e,`--- PART END ---`,``,i].join(`
`):[`=== CONTEXT TRANSFER — Part ${t} of ${n} ===`,`Combine this with the previous part(s). More parts are coming.`,``,`--- PART START ---`,e,`--- PART END ---`,``,a].join(`
`)}function p(e){let t=[()=>m(e),()=>h(),()=>g(),()=>_(e)],n=[];for(let e of t)try{let t=e();if(t.length>n.length&&(n=t),n.length>=4)break}catch{}return n.length>0?n:y(e)}function m(e){return x(r(e.userMessages),r(e.assistantMessages))}function h(){let e=[];for(let t of document.querySelectorAll(`[data-testid]`)){let n=b((t.getAttribute(`data-testid`)??``).toLowerCase());if(n&&!(C(t).length<15)&&!e.some(e=>e.el.contains(t))){for(let n=e.length-1;n>=0;n--)t.contains(e[n].el)&&e.splice(n,1);e.push({el:t,role:n})}}return S(e)}function g(){let e=[];for(let t of document.querySelectorAll(`[class]`)){let n=b((typeof t.className==`string`?t.className:``).toLowerCase());if(n&&!(C(t).length<15)&&!e.some(e=>e.el.contains(t))){for(let n=e.length-1;n>=0;n--)t.contains(e[n].el)&&e.splice(n,1);e.push({el:t,role:n})}}return S(e)}function _(e){let t=n(e.chatContainer);if(!t)return[];let r=[t];for(let e=0;e<6;e++){let e=[];for(let t of r)for(let n of Array.from(t.children))C(n).length>=15&&e.push(n);if(e.length>=3)return v(e);if(e.length===0)break;r=e}return v(r)}function v(e){let t=[],n=`user`;for(let r of e){let e=b(((r.getAttribute(`data-testid`)??``)+` `+(typeof r.className==`string`?r.className:``)).toLowerCase())??n;n=e===`user`?`assistant`:`user`,t.push({el:r,role:e})}return S(t)}function y(e){let t=n(e.chatContainer)??document.querySelector(`main`);if(!t)return[];let r=C(t).trim();return r?[{role:`assistant`,text:r,id:u(`assistant`,r)}]:[]}function b(e){return/human[\-_]?turn|user[\-_]?turn|human[\-_]?message|user[\-_]?message/.test(e)?`user`:/ai[\-_]?turn|assistant[\-_]?turn|claude[\-_]?turn|ai[\-_]?message|assistant[\-_]?message/.test(e)?`assistant`:/\bhuman\b|\buser\b/.test(e)&&!/copilot|chat|input|button|icon|header|nav|side/.test(e)?`user`:/\bai\b|\bassistant\b|\bclaude\b/.test(e)&&!/copilot|chat|input|button|icon|header|nav|side/.test(e)?`assistant`:null}function x(e,t){return S([...e.map(e=>({el:e,role:`user`})),...t.map(e=>({el:e,role:`assistant`}))])}function S(e){e.sort((e,t)=>e.el.compareDocumentPosition(t.el)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);let t=[];for(let{el:n,role:r}of e){let e=C(n).trim();e.length>=5&&t.push({role:r,text:e,id:u(r,e)})}return t}function C(e){if(!(e instanceof HTMLElement))return e.textContent??``;let t=e.innerText;return t&&t.trim()?t:(e.textContent??``).replace(/[ \t]{2,}/g,` `).trim()}var w=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set,T=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,`value`)?.set;function E(e,t){e instanceof HTMLInputElement&&w?w.call(e,t):e instanceof HTMLTextAreaElement&&T?T.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0,cancelable:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0,cancelable:!0}))}async function D(e,t){e.focus(),await new Promise(e=>setTimeout(e,0));let n=window.getSelection();if(n){let t=document.createRange();t.selectNodeContents(e),n.removeAllRanges(),n.addRange(t)}document.execCommand(`insertText`,!1,t)||(e.textContent=t,O(e),e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}))),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function O(e){let t=window.getSelection();if(!t)return;let n=document.createRange();n.selectNodeContents(e),n.collapse(!1),t.removeAllRanges(),t.addRange(n)}function k(e){let t={bubbles:!0,cancelable:!0,key:`Enter`,code:`Enter`,keyCode:13,which:13,composed:!0};e.dispatchEvent(new KeyboardEvent(`keydown`,t)),e.dispatchEvent(new KeyboardEvent(`keypress`,t)),e.dispatchEvent(new KeyboardEvent(`keyup`,t))}function A(e){let t={bubbles:!0,cancelable:!0,composed:!0};e.dispatchEvent(new MouseEvent(`mousedown`,t)),e.dispatchEvent(new MouseEvent(`mouseup`,t)),e.click()}async function j(e,t,n,r={}){let{autoSubmit:i=!1}=r,a=typeof t==`function`?t:()=>t;if(e.scrollIntoView({behavior:`smooth`,block:`center`}),e.focus(),await M(60),e.getAttribute(`contenteditable`)===`true`||e.isContentEditable?await D(e,n):E(e,n),await M(120),i)for(let t=0;t<3;t++){t>0&&(e.focus(),await M(150));let n=a();if(n?.isConnected?A(n):k(e),await M(500),e.isContentEditable?!(e.textContent??``).trim():!(e.value??``).trim())return}}var M=e=>new Promise(t=>setTimeout(t,e));async function N(e){e.getAttribute(`contenteditable`)===`true`||e.isContentEditable?await D(e,``):E(e,``)}function P(e,t=document){let n=t.querySelector(e);if(n)return n;for(let n of t.querySelectorAll(`*`)){let t=n.shadowRoot;if(t){let n=P(e,t);if(n)return n}}return null}function F(e,t=document,n=[]){n.push(...t.querySelectorAll(e));for(let r of t.querySelectorAll(`*`)){let t=r.shadowRoot;t&&F(e,t,n)}return n}function I(e){let t=window.innerWidth,n=window.innerHeight,r=e.parentElement;for(;r&&r!==document.body;){let e=r.tagName.toLowerCase();if(e===`form`||/^ms-(footer|chat-query|prompt-chip-bar|input-box|bottom-input-bar|text-chunk-input)$/.test(e))return r;let i=r.getBoundingClientRect();if(i.width>t*.45&&i.height>0&&i.height<n*.35&&i.top>n*.5)return r;r=r.parentElement}let i=document.querySelector(`main`);if(i&&i.contains(e)){for(let t of i.children)if(t.contains(e))return t;return i}r=e;for(let e=0;e<10&&r.parentElement&&r.parentElement!==document.body;e++)r=r.parentElement;return r}function L(){let e=document.querySelector(`main, [role="main"]`)??document.body,t=window.innerHeight,n=[...e.querySelectorAll(`[contenteditable="true"], textarea`)].filter(e=>{let n=e.getBoundingClientRect();return n.width>80&&n.height>15&&n.height<350&&n.bottom>t*.3});return n.length?(n.sort((e,t)=>t.getBoundingClientRect().top-e.getBoundingClientRect().top),n[0]):null}var R=/upload|add\s+file|attach|from\s+device|local\s+file/i,z=/send|submit|microphone|mic\b|camera|screenshot|search|stop|clear|delete|remove|emoji|reaction/i;function B(){let e=document.querySelectorAll(`[role="menuitem"],[role="option"],.mat-menu-item,[mat-menu-item],ms-menu-item,li[role="presentation"] button`);for(let t of e)if(R.test((t.textContent??``)+(t.getAttribute(`aria-label`)??``)))return t;return null}async function V(){document.dispatchEvent(new KeyboardEvent(`keydown`,{key:`Escape`,bubbles:!0,cancelable:!0})),await M(150),document.body.dispatchEvent(new MouseEvent(`click`,{bubbles:!0})),await M(150)}function H(e,t=5e3){return new Promise(n=>{let r=!1,i=null,a=e=>{r||(r=!0,i?.disconnect(),HTMLInputElement.prototype.click=o,document.removeEventListener(`click`,s,!0),clearTimeout(c),n(e))},o=HTMLInputElement.prototype.click;HTMLInputElement.prototype.click=function(){this.type===`file`?a(this):o.call(this)};let s=e=>{let t=e.composedPath().find(e=>e instanceof HTMLInputElement&&e.type===`file`);t&&(e.preventDefault(),e.stopImmediatePropagation(),a(t))};document.addEventListener(`click`,s,!0),i=new MutationObserver(()=>{if(r)return;let e=P(`input[type="file"]`);if(e){a(e);return}let t=B();t&&A(t)}),i.observe(document.body,{childList:!0,subtree:!0});let c=setTimeout(()=>a(null),t);A(e);let l=0,u=()=>{if(r||++l>25)return;let e=B();e?A(e):setTimeout(u,200)};setTimeout(u,300)})}async function U(e,t,n=[]){let r=I(e);for(let e=0;e<3;e++){let e=P(`input[type="file"]`,r);if(e)return e;await M(50)}for(let e of document.querySelectorAll(`input[type="file"]`))if(!e.closest(`nav, header, [role="banner"], [role="navigation"]`))return e;if(n.length>0){let t=null;for(let e of n)if(t=P(e,r),t)break;if(!t){let r=document.querySelector(`main`);if(r&&r.contains(e)){for(let i of r.children)if(i.contains(e)){for(let e of n)if(t=P(e,i),t)break;break}}}if(t){let e=await H(t,5e3);if(e)return e}}let i=F(`button,[role="button"]`,r),a=e.getBoundingClientRect(),o=i.filter(n=>{if(n===e||n===t||(n.textContent??``).trim().length>20||z.test(n.getAttribute(`aria-label`)??``))return!1;let r=n.getBoundingClientRect();return!(r.width===0||r.height===0||r.right<a.left-120||r.top>a.bottom+80||r.bottom<a.top-80)});if(!o.length)return null;o.sort((e,t)=>{let n=e.getBoundingClientRect(),r=t.getBoundingClientRect();return Math.hypot(n.left-a.left,n.top-a.top)-Math.hypot(r.left-a.left,r.top-a.top)});for(let e of o.slice(0,8)){let t=await H(e,800);if(t)return t;await V()}return null}function W(e,t=1e4){return new Promise(n=>{let r=!1,i=null,a=()=>{r||(r=!0,i&&clearTimeout(i),o.disconnect(),clearTimeout(s),n())},o=new MutationObserver(()=>{r||(i&&clearTimeout(i),i=setTimeout(a,300))});o.observe(e,{childList:!0,subtree:!0});let s=setTimeout(a,t)})}var G=25e3,K=2e3;async function q(e,t,r={}){let i=n(t.input)??await c(t.input.split(`,`)[0].trim(),8e3)??L();if(!i)throw Error(`[claude] ProseMirror input not found`);await j(i,n(t.submitBtn),e,r)}async function J(e,t,r){let i=n(r.input)??L();if(!i)throw Error(`[claude] Input not found`);let a=await U(i,n(r.submitBtn),[]);if(!a)throw Error(`[claude] No file input found. File upload may not be available on this page.`);let o=new File([e],`context-from-${t}.md`,{type:`text/plain`}),s=new DataTransfer;s.items.add(o),a.files=s.files,a.dispatchEvent(new Event(`change`,{bubbles:!0})),a.dispatchEvent(new InputEvent(`input`,{bubbles:!0})),await W(I(i),1e4),await q(`I've attached our full conversation history from ${t}. Please read the context file and briefly acknowledge the main topics so we can continue from where we left off.`,r,{autoSubmit:!0})}async function Y(e,t,r=null){let i=d(e,G);for(let e=0;e<i.length;e++){let a=e===i.length-1;r?.(e+1,i.length),await q(f(i[e],e+1,i.length,a),t,{autoSubmit:!0});for(let e=0;e<20;e++){let e=n(t.stopBtn);if(e){A(e);break}await M(150)}if(a){let e=n(t.input);e&&await N(e)}else await M(K)}}var X=`claude`,Z,Q;async function $(){window.__aiSyncLoaded||(window.__aiSyncLoaded=!0,Z=await t(X),await chrome.runtime.sendMessage({type:`REGISTER_TAB`,platform:X}),Q=s({onSync:ee}),chrome.runtime.onMessage.addListener(te))}function ee(){Q.setStatus(`Open popup to start sync`)}function te(e,t,n){return(async()=>{try{if(e.type===`INJECT_SYNC`){Q.lock(`Preparing sync…`);try{await Y(e.summary,Z,(e,t)=>{Q.lock(`Sending part ${e} of ${t}…`)})}finally{Q.unlock()}n({ok:!0}),Q.setStatus(`Context sent — waiting for AI…`),l(2e3,9e4).then(()=>{chrome.runtime.sendMessage({type:`SYNC_DONE`}).catch(()=>{}),Q.setStatus(`Context synced successfully`)}).catch(()=>{})}else if(e.type===`INJECT_FILE`){Q.lock(`Uploading context file…`);try{await J(e.markdownContent,e.sourcePlatform,Z)}finally{Q.unlock()}n({ok:!0}),Q.setStatus(`File uploaded — waiting for AI…`),l(2e3,9e4).then(()=>{chrome.runtime.sendMessage({type:`SYNC_DONE`}).catch(()=>{}),Q.setStatus(`Context synced via file!`)}).catch(()=>{})}else e.type===`SCRAPE_CONVERSATION`?n({ok:!0,conversation:p(Z)}):n({error:`Unknown type`})}catch(e){Q.setStatus(`Error: `+String(e)),n({error:String(e)})}})(),!0}window.addEventListener(`beforeunload`,()=>{chrome.runtime.sendMessage({type:`UNREGISTER_TAB`}).catch(()=>{})}),$().catch(console.error)})();