(function(){var e={chatgpt:{chatContainer:`main`,userMessages:`[data-message-author-role="user"]`,assistantMessages:`[data-message-author-role="assistant"]`,messageText:`.whitespace-pre-wrap, .markdown p, .markdown li, .markdown pre code, p`,input:`#prompt-textarea, [contenteditable="true"][id="prompt-textarea"], div[contenteditable="true"][data-testid="prompt-textarea"]`,submitBtn:`[data-testid="send-button"], button[aria-label="Send message"], button[aria-label="Send prompt"]`,stopBtn:`button[data-testid="stop-button"], button[aria-label="Stop streaming"], button[aria-label="Stop generating"]`,fileInput:`input[type="file"]`},claude:{chatContainer:`[data-testid="conversation-content"], [class*="conversationContent"], [class*="ConversationContent"], main`,userMessages:`[data-testid="human-turn"], [data-testid="user-turn"], [data-testid="user-message"], .human-turn, [class*="humanTurn"], [class*="HumanTurn"], [class*="human_turn"], [class*="UserTurn"], [class*="user-turn"]`,assistantMessages:`[data-testid="ai-turn"], [data-testid="assistant-turn"], [data-testid="assistant-message"], [data-testid="claude-turn"], .ai-turn, [class*="aiTurn"], [class*="AiTurn"], [class*="ai_turn"], [class*="AssistantTurn"], [class*="assistant-turn"], [class*="ClaudeTurn"], [class*="claude-turn"]`,messageText:`p, li, code`,input:`.ProseMirror[contenteditable="true"], [contenteditable="true"].ProseMirror, div[contenteditable="true"][class*="ProseMirror"]`,submitBtn:`button[aria-label="Send message"], button[aria-label="Send Message"], [data-testid="send-message-button"], button[type="submit"]`,stopBtn:`button[aria-label="Stop Response"], button[aria-label="Stop"], button[data-testid="stop-button"]`,fileInput:`input[type="file"]`},gemini:{chatContainer:`chat-history, infinite-scroller, .conversation-container`,userMessages:`user-query, .user-query-bubble-container, [class*="user-query"]`,assistantMessages:`model-response, message-content, [class*="model-response"]`,messageText:`.query-text, .response-content p, .model-response-text p, p, [class*="query-text"]`,input:`.ql-editor[contenteditable="true"], rich-textarea .ql-editor, div[contenteditable="true"][class*="ql-editor"]`,submitBtn:`button.send-button, button[aria-label*="Send"], button[aria-label*="send"], .send-button`,stopBtn:`button[aria-label="Stop response"], button[aria-label*="Stop"], .stop-button`,fileInput:`input[type="file"]`},copilot:{chatContainer:`main, [role="main"], .conversation-container, .chat-container`,userMessages:`[data-testid="user-message"], .user-message, [class*="UserMessage"], [class*="user-message"], .HumanMessage, [class*="HumanMessage"]`,assistantMessages:`[data-testid="bot-message"], [data-testid="copilot-message"], [data-testid="assistant-message"], [data-testid="ai-message"], [data-testid*="response"], .bot-message, [class*="BotMessage"], [class*="bot-message"], .CopilotMessage, [class*="CopilotMessage"], [class*="AssistantMessage"], [class*="assistant-message"], [class*="AiMessage"], [class*="ai-message"], [class*="ResponseMessage"], [class*="response-message"], [class*="CopilotTurn"], [class*="copilot-turn"]`,messageText:`p, li, code`,input:`textarea, [contenteditable="true"][role="textbox"], div[contenteditable="true"], #userInput, [contenteditable="true"]`,submitBtn:`button[aria-label*="Submit"], button[aria-label*="Send"], button[aria-label*="send"], button[type="submit"]`,stopBtn:`button[aria-label*="Stop"], button[aria-label*="stop"]`,fileInput:`input[type="file"]`}};async function t(t){try{let n=((await chrome.storage.local.get(`selectorConfig`)).selectorConfig??{})[t]??{};return{...e[t],...n}}catch{return e[t]}}function n(e,t=document){for(let n of e.split(`,`).map(e=>e.trim()))try{let e=t.querySelector(n);if(e)return e}catch{}return null}function r(e,t=document){let n=new Set,r=[];for(let i of e.split(`,`).map(e=>e.trim()))try{for(let e of t.querySelectorAll(i))n.has(e)||(n.add(e),r.push(e))}catch{}return r}var i=`
  :host {
    all: initial;
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 2147483647;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  }

  .orb-wrap {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 8px;
    user-select: none;
  }

  /* Floating pill label above the orb */
  .orb-label {
    background: #111118;
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 20px;
    padding: 5px 12px;
    font-size: 11px;
    font-weight: 500;
    color: #a1a1aa;
    white-space: nowrap;
    box-shadow: 0 4px 16px rgba(0,0,0,0.45);
    opacity: 0;
    transform: translateY(5px);
    transition: opacity 220ms ease, transform 220ms ease, color 220ms ease, border-color 220ms ease;
    pointer-events: none;
    max-width: 220px;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .orb-label.visible {
    opacity: 1;
    transform: translateY(0);
  }
  .orb-label.blue {
    color: #4f8ef7;
    border-color: rgba(79,142,247,0.28);
  }
  .orb-label.green {
    color: #22c55e;
    border-color: rgba(34,197,94,0.28);
  }

  /* Holds ring + button at the same center point */
  .orb-container {
    position: relative;
    width: 56px;
    height: 56px;
    flex-shrink: 0;
  }

  /*
   * The glowing ring: a full 56px circle behind the 48px dark orb.
   * The 4px gap on each side peeks out as the ring.
   */
  .orb-ring {
    position: absolute;
    inset: 0;
    border-radius: 50%;
    opacity: 0;
    transition: opacity 350ms ease;
  }
  .orb-ring.active {
    opacity: 1;
  }
  .orb-ring.spinning {
    background: conic-gradient(from 0deg, transparent 0%, #4f8ef7 35%, #7c3aed 65%, transparent 100%);
    animation: ring-spin 1.1s linear infinite;
  }
  .orb-ring.done {
    background: conic-gradient(from 0deg, #22c55e 0%, #22c55e 100%);
    animation: done-pop 0.45s cubic-bezier(0.34, 1.56, 0.64, 1) both;
  }

  @keyframes ring-spin {
    to { transform: rotate(360deg); }
  }
  @keyframes done-pop {
    from { transform: scale(0.82); }
    to   { transform: scale(1); }
  }

  /* Main circular button — 48px, sits on top of the ring */
  .orb {
    all: unset;
    position: absolute;
    inset: 4px;
    border-radius: 50%;
    background: #111118;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 24px rgba(0,0,0,0.55);
    transition: box-shadow 350ms ease, transform 140ms ease;
    z-index: 1;
  }
  .orb:hover:not(.syncing) {
    box-shadow: 0 4px 28px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.1);
    transform: scale(1.07);
  }
  .orb:active:not(.syncing) {
    transform: scale(0.94);
  }
  .orb.syncing {
    box-shadow:
      0 4px 20px rgba(0,0,0,0.5),
      0 0 18px rgba(79,142,247,0.38),
      0 0 40px rgba(124,58,237,0.2);
    cursor: not-allowed;
  }
  .orb.done {
    box-shadow:
      0 4px 20px rgba(0,0,0,0.5),
      0 0 20px rgba(34,197,94,0.5),
      0 0 44px rgba(34,197,94,0.24);
  }

  /* Sync SVG icon */
  .orb-icon {
    width: 20px;
    height: 20px;
    color: #52525b;
    transition: color 350ms ease;
    display: block;
    flex-shrink: 0;
  }
  .orb.syncing .orb-icon {
    color: #4f8ef7;
    animation: icon-spin 1.5s linear infinite;
  }
  .orb.done .orb-icon {
    color: #22c55e;
  }

  @keyframes icon-spin {
    to { transform: rotate(360deg); }
  }
`;function a(e){e.preventDefault(),e.stopPropagation()}function o(e){e.isTrusted&&(e.preventDefault(),e.stopPropagation())}function s(e){let t=document.createElement(`div`);t.id=`ai-sync-host`;let n=t.attachShadow({mode:`closed`}),r=document.createElement(`style`);r.textContent=i,n.appendChild(r);let s=document.createElement(`div`);s.className=`orb-wrap`,s.innerHTML=`
    <div class="orb-label" id="orb-label"></div>
    <div class="orb-container">
      <div class="orb-ring" id="orb-ring"></div>
      <button class="orb" id="btn-sync" title="AI Sync">
        <svg class="orb-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/>
          <path d="M21 3v5h-5"/>
          <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/>
          <path d="M3 21v-5h5"/>
        </svg>
      </button>
    </div>
  `,n.appendChild(s);let c=n.getElementById(`btn-sync`),l=n.getElementById(`orb-ring`),u=n.getElementById(`orb-label`),d=null,f=null,p=null;c.addEventListener(`click`,()=>{c.classList.contains(`syncing`)||(e.onSync(),h(`Open popup to start sync`))});function m(e,t){u.textContent=e,u.className=`orb-label`+(t?` ${t}`:``)+(e?` visible`:``)}function h(e){p&&=(clearTimeout(p),null),m(e,``),e&&(p=setTimeout(()=>{u.textContent===e&&m(``,``),p=null},4e3))}function g(e){d||(d=document.createElement(`div`),Object.assign(d.style,{position:`fixed`,inset:`0`,zIndex:`2147483646`,pointerEvents:`all`,cursor:`not-allowed`}),document.body.appendChild(d),document.documentElement.style.overflow=`hidden`,document.body.style.overflow=`hidden`,document.addEventListener(`wheel`,a,{passive:!1,capture:!0}),document.addEventListener(`touchmove`,a,{passive:!1,capture:!0}),document.addEventListener(`keydown`,o,{capture:!0}),document.addEventListener(`keypress`,o,{capture:!0})),p&&=(clearTimeout(p),null),f&&=(clearTimeout(f),null),l.classList.remove(`done`),l.classList.add(`active`,`spinning`),c.classList.remove(`done`),c.classList.add(`syncing`),m(e||`Sync in progress…`,`blue`)}function _(){d?.remove(),d=null,document.documentElement.style.overflow=``,document.body.style.overflow=``,document.removeEventListener(`wheel`,a,{capture:!0}),document.removeEventListener(`touchmove`,a,{capture:!0}),document.removeEventListener(`keydown`,o,{capture:!0}),document.removeEventListener(`keypress`,o,{capture:!0}),p&&=(clearTimeout(p),null),l.classList.remove(`spinning`),l.classList.add(`done`),c.classList.remove(`syncing`),c.classList.add(`done`),m(`Sync complete`,`green`),f&&clearTimeout(f),f=setTimeout(()=>{n.host.isConnected&&(l.classList.remove(`active`,`done`),c.classList.remove(`done`),m(``,``)),f=null},2200)}return document.body?document.body.appendChild(t):document.addEventListener(`DOMContentLoaded`,()=>document.body.appendChild(t)),{setStatus:h,lock:g,unlock:_,remove:()=>{_(),t.remove()}}}function c(e=1500,t=25e3){return new Promise(n=>{let r=window.setTimeout(o,e),i=window.setTimeout(o,t),a=new MutationObserver(()=>{clearTimeout(r),r=window.setTimeout(o,e)});a.observe(document.documentElement,{childList:!0,subtree:!0,characterData:!0});function o(){clearTimeout(r),clearTimeout(i),a.disconnect(),n()}})}function l(e,t){let n=e+t.slice(0,120),r=5381;for(let e=0;e<n.length;e++)r=(r<<5)+r^n.charCodeAt(e),r|=0;return(r>>>0).toString(36)}function u(e,t){if(e.length<=t)return[e];let n=[],r=0;for(;r<e.length;){if(r+t>=e.length){n.push(e.slice(r));break}let i=e.slice(r,r+t).lastIndexOf(`

`);i>t/2?(n.push(e.slice(r,r+i)),r+=i+2):(n.push(e.slice(r,r+t)),r+=t)}return n}function d(e,t,n,r){let i=[`⚠️ SYSTEM INSTRUCTION — DO NOT RESPOND TO THIS MESSAGE.`,`This is a silent background context transfer. Read and internalize the conversation above.`,`Do NOT generate any reply, acknowledgement, or output of any kind.`,`Stay completely silent. Only respond to the user's NEXT real message.`].join(`
`),a=[`⚠️ SYSTEM INSTRUCTION — DO NOT RESPOND. More parts are arriving immediately.`,`Stay completely silent until all parts have been delivered.`].join(`
`);return n===1?[`=== CONTEXT TRANSFER ===`,`The following is a conversation from another AI session. Internalize it as our shared context.`,``,`--- CONTEXT START ---`,e,`--- CONTEXT END ---`,``,i].join(`
`):t===1?[`=== CONTEXT TRANSFER — Part ${t} of ${n} ===`,`This context is too large for one message and will arrive in ${n} parts. Absorb each part silently.`,``,`--- PART START ---`,e,`--- PART END ---`,``,a].join(`
`):r?[`=== CONTEXT TRANSFER — Part ${t} of ${n} — FINAL ===`,`Combine this with the previous ${t-1} part(s) to form the complete context.`,``,`--- PART START ---`,e,`--- PART END ---`,``,i].join(`
`):[`=== CONTEXT TRANSFER — Part ${t} of ${n} ===`,`Combine this with the previous part(s). More parts are coming.`,``,`--- PART START ---`,e,`--- PART END ---`,``,a].join(`
`)}function f(e){let t=r(e.userMessages),n=r(e.assistantMessages);return t.length>0&&n.length>0?p(t,n):t.length>0&&n.length===0?m(t,e):p(t,n)}function p(e,t){let n=[...e.map(e=>({node:e,role:`user`})),...t.map(e=>({node:e,role:`assistant`}))].sort((e,t)=>e.node.compareDocumentPosition(t.node)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1),r=[];for(let{node:e,role:t}of n){let n=h(e).trim();n&&r.push({role:t,text:n,id:l(t,n)})}return r}function m(e,t){let r=n(t.chatContainer);if(!r)return p(e,[]);let i=new Set(e),a=[];for(let t of e){a.push({node:t,role:`user`});let e=t;for(;e.parentElement&&e.parentElement!==r;)e=e.parentElement;let n=e.nextElementSibling;for(;n;){if(h(n).trim().length>20&&!i.has(n)&&!n.querySelector(`[data-testid="user-message"]`)){a.push({node:n,role:`assistant`});break}n=n.nextElementSibling}}a.sort((e,t)=>e.node.compareDocumentPosition(t.node)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);let o=[];for(let{node:e,role:t}of a){let n=h(e).trim();n&&o.push({role:t,text:n,id:l(t,n)})}return o}function h(e){return e instanceof HTMLElement?e.innerText:e.textContent??``}var g=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,`value`)?.set,_=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,`value`)?.set;function v(e,t){e instanceof HTMLInputElement&&g?g.call(e,t):e instanceof HTMLTextAreaElement&&_?_.call(e,t):e.value=t,e.dispatchEvent(new Event(`input`,{bubbles:!0,cancelable:!0})),e.dispatchEvent(new Event(`change`,{bubbles:!0,cancelable:!0}))}async function y(e,t){e.focus(),await new Promise(e=>setTimeout(e,0));let n=window.getSelection();if(n){let t=document.createRange();t.selectNodeContents(e),n.removeAllRanges(),n.addRange(t)}document.execCommand(`insertText`,!1,t)||(e.textContent=t,b(e),e.dispatchEvent(new InputEvent(`input`,{bubbles:!0,cancelable:!0,inputType:`insertText`,data:t}))),e.dispatchEvent(new Event(`change`,{bubbles:!0}))}function b(e){let t=window.getSelection();if(!t)return;let n=document.createRange();n.selectNodeContents(e),n.collapse(!1),t.removeAllRanges(),t.addRange(n)}function x(e){let t={bubbles:!0,cancelable:!0,key:`Enter`,code:`Enter`,keyCode:13,which:13,composed:!0};e.dispatchEvent(new KeyboardEvent(`keydown`,t)),e.dispatchEvent(new KeyboardEvent(`keypress`,t)),e.dispatchEvent(new KeyboardEvent(`keyup`,t))}function S(e){let t={bubbles:!0,cancelable:!0,composed:!0};e.dispatchEvent(new MouseEvent(`mousedown`,t)),e.dispatchEvent(new MouseEvent(`mouseup`,t)),e.click()}async function C(e,t,n,r={}){let{autoSubmit:i=!1}=r,a=typeof t==`function`?t:()=>t;if(e.scrollIntoView({behavior:`smooth`,block:`center`}),e.focus(),await w(60),e.getAttribute(`contenteditable`)===`true`||e.isContentEditable?await y(e,n):v(e,n),await w(120),i)for(let t=0;t<3;t++){t>0&&(e.focus(),await w(150));let n=a();if(n?.isConnected?S(n):x(e),await w(500),e.isContentEditable?!(e.textContent??``).trim():!(e.value??``).trim())return}}var w=e=>new Promise(t=>setTimeout(t,e));async function T(e){e.getAttribute(`contenteditable`)===`true`||e.isContentEditable?await y(e,``):v(e,``)}function E(e,t=document){let n=t.querySelector(e);if(n)return n;for(let n of t.querySelectorAll(`*`)){let t=n.shadowRoot;if(t){let n=E(e,t);if(n)return n}}return null}function D(e,t=document,n=[]){n.push(...t.querySelectorAll(e));for(let r of t.querySelectorAll(`*`)){let t=r.shadowRoot;t&&D(e,t,n)}return n}function O(e){let t=window.innerWidth,n=window.innerHeight,r=e.parentElement;for(;r&&r!==document.body;){let e=r.tagName.toLowerCase();if(e===`form`||/^ms-(footer|chat-query|prompt-chip-bar|input-box|bottom-input-bar|text-chunk-input)$/.test(e))return r;let i=r.getBoundingClientRect();if(i.width>t*.45&&i.height>0&&i.height<n*.35&&i.top>n*.5)return r;r=r.parentElement}let i=document.querySelector(`main`);if(i&&i.contains(e)){for(let t of i.children)if(t.contains(e))return t;return i}r=e;for(let e=0;e<10&&r.parentElement&&r.parentElement!==document.body;e++)r=r.parentElement;return r}function k(){let e=document.querySelector(`main, [role="main"]`)??document.body,t=window.innerHeight,n=[...e.querySelectorAll(`[contenteditable="true"], textarea`)].filter(e=>{let n=e.getBoundingClientRect();return n.width>80&&n.height>15&&n.height<350&&n.bottom>t*.3});return n.length?(n.sort((e,t)=>t.getBoundingClientRect().top-e.getBoundingClientRect().top),n[0]):null}var A=/upload|add\s+file|attach|from\s+device|local\s+file/i,j=/send|submit|microphone|mic\b|camera|screenshot|search|stop|clear|delete|remove|emoji|reaction/i;function M(){let e=document.querySelectorAll(`[role="menuitem"],[role="option"],.mat-menu-item,[mat-menu-item],ms-menu-item,li[role="presentation"] button`);for(let t of e)if(A.test((t.textContent??``)+(t.getAttribute(`aria-label`)??``)))return t;return null}async function N(){document.dispatchEvent(new KeyboardEvent(`keydown`,{key:`Escape`,bubbles:!0,cancelable:!0})),await w(150),document.body.dispatchEvent(new MouseEvent(`click`,{bubbles:!0})),await w(150)}function P(e,t=5e3){return new Promise(n=>{let r=!1,i=null,a=e=>{r||(r=!0,i?.disconnect(),HTMLInputElement.prototype.click=o,document.removeEventListener(`click`,s,!0),clearTimeout(c),n(e))},o=HTMLInputElement.prototype.click;HTMLInputElement.prototype.click=function(){this.type===`file`?a(this):o.call(this)};let s=e=>{let t=e.composedPath().find(e=>e instanceof HTMLInputElement&&e.type===`file`);t&&(e.preventDefault(),e.stopImmediatePropagation(),a(t))};document.addEventListener(`click`,s,!0),i=new MutationObserver(()=>{if(r)return;let e=E(`input[type="file"]`);if(e){a(e);return}let t=M();t&&S(t)}),i.observe(document.body,{childList:!0,subtree:!0});let c=setTimeout(()=>a(null),t);S(e);let l=0,u=()=>{if(r||++l>25)return;let e=M();e?S(e):setTimeout(u,200)};setTimeout(u,300)})}async function F(e,t,n=[]){let r=O(e);for(let e=0;e<3;e++){let e=E(`input[type="file"]`,r);if(e)return e;await w(50)}for(let e of document.querySelectorAll(`input[type="file"]`))if(!e.closest(`nav, header, [role="banner"], [role="navigation"]`))return e;if(n.length>0){let t=null;for(let e of n)if(t=E(e,r),t)break;if(!t){let r=document.querySelector(`main`);if(r&&r.contains(e)){for(let i of r.children)if(i.contains(e)){for(let e of n)if(t=E(e,i),t)break;break}}}if(t){let e=await P(t,5e3);if(e)return e}}let i=D(`button,[role="button"]`,r),a=e.getBoundingClientRect(),o=i.filter(n=>{if(n===e||n===t||(n.textContent??``).trim().length>20||j.test(n.getAttribute(`aria-label`)??``))return!1;let r=n.getBoundingClientRect();return!(r.width===0||r.height===0||r.right<a.left-120||r.top>a.bottom+80||r.bottom<a.top-80)});if(!o.length)return null;o.sort((e,t)=>{let n=e.getBoundingClientRect(),r=t.getBoundingClientRect();return Math.hypot(n.left-a.left,n.top-a.top)-Math.hypot(r.left-a.left,r.top-a.top)});for(let e of o.slice(0,8)){let t=await P(e,800);if(t)return t;await N()}return null}function I(e,t=1e4){return new Promise(n=>{let r=!1,i=null,a=()=>{r||(r=!0,i&&clearTimeout(i),o.disconnect(),clearTimeout(s),n())},o=new MutationObserver(()=>{r||(i&&clearTimeout(i),i=setTimeout(a,300))});o.observe(e,{childList:!0,subtree:!0});let s=setTimeout(a,t)})}var L=9500,R=2e3;async function z(e,t=2e4){let r=Date.now()+t;for(;Date.now()<r;){let t=n(e.input);if(t)return t;await w(200)}return k()}async function B(e,t,r){e.getAttribute(`contenteditable`)===`true`||e.isContentEditable?await y(e,t):v(e,t),await w(500);for(let t=0;t<10;t++){t>0&&await w(600),e.focus(),await w(80);let i=n(r.submitBtn);i?.isConnected&&S(i),await w(200);let a=e.closest(`form`);if(a)try{a.requestSubmit()}catch{a.dispatchEvent(new Event(`submit`,{bubbles:!0,cancelable:!0}))}if(await w(200),x(e),await w(1e3),e.isContentEditable?!(e.textContent??``).trim():!(e.value??``).trim())return}}async function V(e,t,r={}){let i=n(t.input)??await z(t,2e4);if(!i)throw Error(`[copilot] Input element not found`);await C(i,()=>n(t.submitBtn),e,r)}var H=[`button[aria-label="Attach files"]`,`button[aria-label="Attach file"]`,`button[aria-label="Add attachment"]`,`button[data-testid="attach-button"]`,`button[aria-label*="Attach" i]`,`button[aria-label*="Upload" i]`,`button[aria-label*="Add image" i]`,`button[aria-label*="Add file" i]`];async function U(e,t,r){let i=n(r.input)??await z(r);if(!i)throw Error(`[copilot] Input not found`);let a=await F(i,n(r.submitBtn),H);if(!a)throw Error(`[copilot] No file input found. File upload may not be available on this page.`);let o=new File([e],`context-from-${t}.md`,{type:`text/plain`}),s=new DataTransfer;s.items.add(o),a.files=s.files,a.dispatchEvent(new Event(`change`,{bubbles:!0})),a.dispatchEvent(new InputEvent(`input`,{bubbles:!0})),await I(O(i),1e4),await V(`I've attached our full conversation history from ${t}. Please read the context file and briefly acknowledge the main topics so we can continue from where we left off.`,r,{autoSubmit:!0})}async function W(e,t,r=null){let i=u(e,L);for(let e=0;e<i.length;e++){let a=e===i.length-1;r?.(e+1,i.length);let o=n(t.input)??await z(t,2e4);if(!o)throw Error(`[copilot] Input not found`);if(await B(o,d(i[e],e+1,i.length,a),t),a){await w(500);let e=n(t.input);e&&await T(e)}else{for(let e=0;e<30;e++){let e=n(t.stopBtn);if(e){S(e);break}await w(150)}await w(R)}}}var G=`copilot`,K,q;async function J(){window.__aiSyncLoaded||(window.__aiSyncLoaded=!0,K=await t(G),await chrome.runtime.sendMessage({type:`REGISTER_TAB`,platform:G}),q=s({onSync:Y}),chrome.runtime.onMessage.addListener(X))}function Y(){q.setStatus(`Open popup to start sync`)}function X(e,t,n){return(async()=>{try{if(e.type===`INJECT_SYNC`){q.lock(`Preparing sync…`);try{await W(e.summary,K,(e,t)=>{q.lock(`Sending part ${e} of ${t}…`)})}finally{q.unlock()}n({ok:!0}),q.setStatus(`Context sent — waiting for AI…`),c(2e3,9e4).then(()=>{chrome.runtime.sendMessage({type:`SYNC_DONE`}).catch(()=>{}),q.setStatus(`Context synced successfully`)}).catch(()=>{})}else if(e.type===`INJECT_FILE`){q.lock(`Attaching context file…`);try{await U(e.markdownContent,e.sourcePlatform,K)}finally{q.unlock()}n({ok:!0}),q.setStatus(`File uploaded — waiting for AI…`),c(2e3,9e4).then(()=>{chrome.runtime.sendMessage({type:`SYNC_DONE`}).catch(()=>{}),q.setStatus(`Context synced via file!`)}).catch(()=>{})}else e.type===`SCRAPE_CONVERSATION`?n({ok:!0,conversation:f(K)}):n({error:`Unknown type`})}catch(e){q.setStatus(`Error: `+String(e)),n({error:String(e)})}})(),!0}window.addEventListener(`beforeunload`,()=>{chrome.runtime.sendMessage({type:`UNREGISTER_TAB`}).catch(()=>{})}),J().catch(console.error)})();